﻿using System;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Media.Imaging;
using Accord.Video;
using Accord.Video.DirectShow;
using Tevian.FaceSdkWrapper;

namespace LivenessDetector
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		private readonly FilterInfoCollection _videoDevices = new FilterInfoCollection(FilterCategory.VideoInputDevice);
		private VideoCaptureDevice CaptureDevice;
		private BitmapImage Snapshot;

		private ConfigManager mngr = new ConfigManager();
		private Detector detector;
		private int _width;
		private int _height;
		private Roi _roi;
		private SizeTva _minSize;
		private SizeTva _maxSize;
		private float _precision = 0.8f;
		private int _frameNum = 0;
		private float _score = -1.0f;
		private Tevian.FaceSdkWrapper.LivenessDetector _livenessDetector;
		public MainWindow()
		{
			InitializeComponent();
			foreach (FilterInfo videoDevice in _videoDevices)
			{
				TbLog.Text += videoDevice.Name + "\n";
			}
		}
		private static VideoCapabilities selectResolution(VideoCaptureDevice device)
		{
			foreach (var cap in device.VideoCapabilities)
			{
				if (cap.FrameSize.Height == 960)
					return cap;
				if (cap.FrameSize.Width == 1280)
					return cap;
			}

			return device.VideoCapabilities.Last();
		}

		private void BtnStart_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				detector = new Detector(mngr);
				Snapshot = new BitmapImage();
				CaptureDevice = new VideoCaptureDevice(_videoDevices[0].MonikerString);
				CaptureDevice.VideoResolution = selectResolution(CaptureDevice);
				CaptureDevice.NewFrame += CaptureDeviceOnNewFrame;
				_width = CaptureDevice.VideoResolution.FrameSize.Width;
				_height = CaptureDevice.VideoResolution.FrameSize.Height;
				_roi = new Roi(0,0,(uint)_width, (uint)_height);
				_minSize = new SizeTva((uint)(_width * 0.05), (uint)(_height* 0.05));
				// define maximal head size as 95% of image size
				_maxSize = new SizeTva((uint)(_width * 0.95), (uint)(_height * 0.95));
				// set precision_level - threshold on detection scores

				_livenessDetector = new Tevian.FaceSdkWrapper.LivenessDetector(mngr);
				CaptureDevice.Start();
			}
			catch (Exception ex)
			{
				TbLog.Text += ex.Message;
			}
		}
		private async void CaptureDeviceOnNewFrame(object sender, NewFrameEventArgs eventargs)
		{
			var tmp = await CaptureDevice.GetSnapshot();
			Snapshot = tmp.ToImageSource() as BitmapImage;
			ImgFrame.Source = Snapshot;
			var frame = new ImageTva(BitmapImage2Bitmap(Snapshot));
			var faces1 = detector.Detect(frame, _roi, _minSize, _maxSize, _precision);

			// check number of faces
			if (faces1.Count < 1)
			{
				TbLog.Text += "No faces on the first image";
				return;
			}
			var face1 = faces1[0];
			_score = _livenessDetector.Process(frame, face1.BoundingBox, (int)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds);
			TbScore.Text = _score.ToString(CultureInfo.InvariantCulture);
		}
		private Bitmap BitmapImage2Bitmap(BitmapImage bitmapImage)
		{
			// BitmapImage bitmapImage = new BitmapImage(new Uri("../Images/test.png", UriKind.Relative));

			using (MemoryStream outStream = new MemoryStream())
			{
				BitmapEncoder enc = new BmpBitmapEncoder();
				enc.Frames.Add(BitmapFrame.Create(bitmapImage));
				enc.Save(outStream);
				System.Drawing.Bitmap bitmap = new System.Drawing.Bitmap(outStream);

				return new Bitmap(bitmap);
			}
		}
		private void BtnStop_Click(object sender, RoutedEventArgs e)
		{
			CaptureDevice.SignalToStop();
			CaptureDevice.NewFrame -= CaptureDeviceOnNewFrame;
			CaptureDevice = null;
		}
	}
}
