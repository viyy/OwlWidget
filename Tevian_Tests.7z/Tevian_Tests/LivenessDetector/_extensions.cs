﻿using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Accord.Video;
using Accord.Video.DirectShow;

namespace LivenessDetector
{
	public static class _extensions
	{
		public static Task<byte[]> GetSnapshot(this VideoCaptureDevice videoSource)
		{
			return Task.Run(() =>
			{
				var _autoResetEvent = new AutoResetEvent(false);
				byte[] array = null;
				NewFrameEventHandler action = (sender, args) =>
				{
					array = args.Frame.ToByteArray();
					_autoResetEvent.Set();
				};
				videoSource.NewFrame += action;
				_autoResetEvent.WaitOne();
				videoSource.NewFrame -= action;
				return array;
			});
		}
		private static byte[] ToByteArray(this Image img)
		{
			var bitmap = new Bitmap(img);
			var myImageCodecInfo = GetEncoderInfo("image/jpeg");
			var myEncoder = Encoder.Quality;
			var myEncoderParameters = new EncoderParameters(1);
			var myEncoderParameter = new EncoderParameter(myEncoder, 25L);
			myEncoderParameters.Param[0] = myEncoderParameter;
			var stream = new MemoryStream();
			bitmap.Save(stream, myImageCodecInfo, myEncoderParameters);
			Image i = new Bitmap(stream);
			var converter = new ImageConverter();
			return (byte[])converter.ConvertTo(i, typeof(byte[]));
		}

		private static ImageCodecInfo GetEncoderInfo(string mimeType)
		{
			int j;
			ImageCodecInfo[] encoders;
			encoders = ImageCodecInfo.GetImageEncoders();
			for (j = 0; j < encoders.Length; ++j)
				if (encoders[j].MimeType == mimeType)
					return encoders[j];
			return null;
		}

		public static ImageSource ToImageSource(this byte[] imageData)
		{
			if (imageData == null || imageData.Length == 0) return null;
			try
			{
				var image = new BitmapImage();
				using (var mem = new MemoryStream(imageData))
				{
					mem.Position = 0;
					image.BeginInit();
					image.CreateOptions = BitmapCreateOptions.PreservePixelFormat;
					image.CacheOption = BitmapCacheOption.OnLoad;
					image.UriSource = null;
					image.StreamSource = mem;
					image.EndInit();
				}

				image.Freeze();
				return image;
			}
			catch
			{
				return null;
			}
		}

		public static void Save(this BitmapImage image, string filePath)
		{
			BitmapEncoder encoder = new PngBitmapEncoder();
			encoder.Frames.Add(BitmapFrame.Create(image));

			using (var fileStream = new FileStream(filePath, FileMode.Create))
			{
				encoder.Save(fileStream);
			}
		}
	}
}